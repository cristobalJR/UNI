#include <stdio.h>

#define TV 6
#define NF 2
#define NC 3

int main ()
{
  int i,j,a[6];
  float b[2][3];
  int *punt_a;
  float *punt_b;

  // Direcciones de los elementos de los punteros
  printf("Direcciones de los elementos del vector a\n");
  for (i = 0; i < TV; i++)
    printf("Dir(a[%d]) = %p\n",i,&(a[i]));
  printf("Direcciones de la matriz b\n");
  for (i = 0; i < NF; i++)
    for (j = 0; j < NC; j++) {
      printf("Dir(b[%d][%d]) = %p\n",i,j,&(b[i][j]));
    }
  printf("Direcci�n de a[6] = %p\n",&a[6]);
  printf("Direcci�n de a[7] = %p\n",&a[7]);

  printf("Introduce los elementos de a:\n");
  for (i = 0; i < TV; i++) {
    printf("a[%d] = ",i);
    scanf("%d",&(a[i]));
  }

  printf("Acceso a datos mediante �ndices\n");
  for (i = 0; i < TV; i++) {
    printf("a[%d] = %d\n",i,a[i]);
  }

  printf("Acceso a datos a trav�s de puntero\n");
  punt_a = a;
  for (i = 0; i < TV; i++) {
    printf("a[%d] = %d\n",i,punt_a[i]);
  }

  a[6] = 0x3f800000;
  a[7] = 0x40000000;
  // a[6] y b[0][0] son el mismo objeto, ya que tienen id�ntica direcci�n
  printf("Valor de a[6] = %d --- %f\n",a[6],b[0][0]);
  // Igual pasa con a[7] y b[0][1]
  printf("Valor de a[7] = %d --- %f\n",a[7],b[0][1]);


  punt_a = a;
  punt_b = (float *) b;
  printf("Copia en b a trav�s de punteros con conversi�n autom�tica de tipo\n");
  for (i = 0; i < NF; i++)
    for (j = 0; j < NC; punt_a++, punt_b++, j++) {
      *punt_b = *punt_a;
      printf("b[%d][%d] = %f\n",i,j,b[i][j]);
    }

  printf("Fin\n");
  return 0;
}
