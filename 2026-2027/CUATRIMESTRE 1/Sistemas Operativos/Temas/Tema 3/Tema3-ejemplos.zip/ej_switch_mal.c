#include <stdio.h>

int main ()
{
  int opcion;

  printf("Elige opción: ");
  scanf("%d",&opcion);
  switch (opcion) {
    case 1:
      printf("Opción elegida: 1\n");
    case 2:
      printf("Opción elegida: 2\n");
    case 3:
      printf("Opción elegida: 3\n");
    default:
      printf("Elegida opción por defecto: %d\n",opcion);
  }
  return 0;
}
