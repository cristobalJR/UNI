#include <stdio.h>

/* Punto de entrada
   del programa */
int main ()
{
  // Llamada a printf
  printf("Hola mundo\n");
  return 0;
}
