#include <stdio.h>

int main ()
{
  int opcion;

  printf("Elige opci�n: ");
  scanf("%d",&opcion);
  if (opcion <= 5) {
    printf("Opci�n elegida <= 5: %d\n",opcion);
  }
  else {
    printf("Opci�n elegida > 5: %d\n",opcion);
  }
  return 0;
}
