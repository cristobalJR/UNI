#include <stdio.h>

int main ()
{
  int n, i, factorial;

  printf("Introduce el valor de n: ");
  scanf("%d",&n);
  i = 1;
  factorial = 1;
  do {
    factorial = factorial * i;
    i = i+1;
  } while (i <= n); 
  printf("El factorial de %d es %d\n",n,factorial);
  return 0;
}
