#include <stdio.h>

/* Cabeceras de funciones */
int main (void);
void intercambia (int *a, int *b);
void imprimir_variables (int a, int b);

/* Cuerpo de las funciones */
int main (void)
{
  int x = 10, y = 20;

  imprimir_variables(x,y);
  printf("Valores iniciales de las variables:\n\tx = %d\n\ty = %d\n",x,y);
  intercambia(&x,&y);
  imprimir_variables(x,y);
  printf("Valores finales de las variables:\n\tx = %d\n\ty = %d\n",x,y);
  return 0;
}


// En esta funci�n las variables se pasan por referencia
void intercambia (int *a, int *b)
{
  int aux;

  aux = *a;
  *a = *b;
  *b = aux;
}



// En esta funci�n las variables se pasan por copia
// Si se modificasen, el efecto no se ver�a a la salida
void imprimir_variables (int a, int b)
{
  printf("La primera variable vale %d y la segunda vale %d\n",a,b);
  a = 50;
  b = 60;
  printf("Ahora la primera variable vale %d y la segunda vale %d\n",a,b);

}
