#include <stdio.h>
#include <errno.h>
#include <string.h>

int main (void);

int main (void)
{
  FILE *f1;

  f1 = fopen("./out.txt","r+");
  //  if ((f1 = fopen(".out.txt","r+")) == NULL)
  //  if (!f1)
  if (f1 == NULL)
    printf("Error al abrir el fichero. %s\n",strerror(errno));
  else {
    fprintf(f1,"Hola mundo\n");
    // Ser�a recomendable cerrar el fichero
    // fclose(f1);
  }
}
