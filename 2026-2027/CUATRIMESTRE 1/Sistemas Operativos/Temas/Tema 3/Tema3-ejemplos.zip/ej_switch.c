#include <stdio.h>

int main ()
{
  int opcion;

  printf("Elige opci�n: ");
  scanf("%d",&opcion);
  switch (opcion) {
    case 1:
      printf("Opci�n elegida: 1\n");
      break;
    case 2:
      printf("Opci�n elegida: 2\n");
      break;
    case 3:
      printf("Opci�n elegida: 3\n");
      break;
    default:
      printf("Elegida opci�n por defecto: %d\n",opcion);
      break;
  }
  return 0;
}
