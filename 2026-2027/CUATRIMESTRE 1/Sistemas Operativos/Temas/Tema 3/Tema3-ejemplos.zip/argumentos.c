#include <stdio.h>

int main (int argc, char *argv[])
{
  printf("Se han recibido %d argumentos\n",argc);
  int i;
  for (i=0;i<argc;i++)
    printf("Argumento %d = %s\n",i,argv[i]);
  return 0;
}
