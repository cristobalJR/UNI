#include <stdio.h>

int main ()
{
  int n, i, factorial;

  printf("Introduce el valor de n: ");
  scanf("%d",&n);
  i = 2;
  factorial = 1;
  while (i <= n) {
    factorial = factorial * i;
    i = i+1;
  }
  printf("El factorial de %d es %d\n",n,factorial);
  return 0;
}
