#include <stdio.h>

int main ()
{
  int n, i, factorial;

  printf("Introduce el valor de n: ");
  scanf("%d",&n);
  factorial = 1;
  for (i = 2; i <= n; i++) {
    factorial = factorial * i;
  }
  printf("El factorial de %d es %d\n",n,factorial);
  return 0;
}
