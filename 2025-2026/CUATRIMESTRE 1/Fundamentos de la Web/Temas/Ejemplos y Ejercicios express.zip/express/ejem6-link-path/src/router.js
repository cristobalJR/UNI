import express from 'express';

const router = express.Router();
export default router;

router.get('/offers/:city', (req, res) => {

    res.render('offers', {
        city: req.params.city,
    });
});

