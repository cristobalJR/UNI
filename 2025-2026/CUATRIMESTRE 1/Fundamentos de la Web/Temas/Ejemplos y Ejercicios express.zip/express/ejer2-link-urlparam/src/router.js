import express from 'express';

const router = express.Router();
export default router;

router.get('/link', (req, res) => {

    const linkId = req.query.linkId;

    res.render('show_link_id', { linkId });
});


