import express from 'express';

const app = express();

app.get('/', (req, res) => {
   res.send('<html><body><h1>Hello World!</h1></body></html>');
});

app.listen(3000, () => console.log('Web ready in http://localhost:3000/'));