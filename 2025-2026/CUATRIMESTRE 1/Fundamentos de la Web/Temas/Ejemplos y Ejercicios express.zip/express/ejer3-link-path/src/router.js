import express from 'express';

const router = express.Router();
export default router;

router.get('/link/:linkId', (req, res) => {

    const linkId = req.params.linkId;

    res.render('show_link_id', { linkId });
});

