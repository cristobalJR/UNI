import express from 'express';

const router = express.Router();
export default router;

router.get('/offers', (req, res) => {

    res.render('offers', {
        city: req.query.city,
    });
});

