import express from 'express';

const router = express.Router();
export default router;

router.get('/greeting', (req, res) => {

    res.render('greeting', {
        name: req.query.userName,
        country: req.query.country
    });
});

router.post('/login', (req, res) => {

    let password = "1234";

    let success = req.body.password === password;

    res.render('login', {
        success,
        name: req.body.userName,
    });
});

