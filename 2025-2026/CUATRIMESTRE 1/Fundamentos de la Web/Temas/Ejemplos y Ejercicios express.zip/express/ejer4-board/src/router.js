import express from 'express';
import * as board from './board.js';

const router = express.Router();

router.get('/', (req, res) => {

    res.render('index', { 
        posts: board.getPosts() 
    });
});

router.post('/post/new', (req, res) => {

    let post = { 
        user: req.body.user,
        title: req.body.title,
        text: req.body.text
    };

    board.addPost(post);

    res.render('saved_post', { id: post.id });
});

router.get('/post/:id', (req, res) => {

    let post = board.getPost(req.params.id);

    res.render('show_post', { post });
});

router.get('/post/:id/delete', (req, res) => {

    board.deletePost(req.params.id);

    res.render('deleted_post');
});

export default router;