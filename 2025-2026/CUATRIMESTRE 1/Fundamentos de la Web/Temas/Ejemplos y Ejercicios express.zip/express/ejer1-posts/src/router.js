import express from 'express';

const router = express.Router();
export default router;

router.post('/new_post', (req, res) => {

    const post = { 
        user: req.body.user, 
        title: req.body.title,
        text: req.body.text
    };

    res.render('show_post', { post });
});

