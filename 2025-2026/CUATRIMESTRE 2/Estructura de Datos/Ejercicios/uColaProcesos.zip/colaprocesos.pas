// Apartado 2: genera n procesos de nombre y prioridad aleatoria 
// y los mete en una cola que hará de buffer del sistema
procedure generar_procesos(var buffer:tColaProcesos; n:integer);
var
  i:integer;
  pproceso: ^tproceso;
begin
  randomize;
  for i:=1 to n do begin
      new(pproceso);
      str(random(1000),pproceso^.id);
      pproceso^.id:= 'P'+pproceso^.id;
      pproceso^.prioridad:= 1 + random(3);
      enqueue(buffer,pproceso^);
      dispose(pproceso);
    end;
end;

// Apartado 2 (versión alternativa): genera n procesos de nombre y prioridad aleatoria 
// y los mete en una cola que hará de buffer del sistema
procedure generar_procesos(var buffer:tColaProcesos; n:integer);
var
  i:integer;
  mi_proceso: tproceso;
begin
  randomize;
  for i:=1 to n do begin
      str(random(1000), mi_proceso.id);
      mi_proceso.id:= 'P' + mi_proceso.id;
      mi_proceso.prioridad:= 1 + random(3);
      enqueue(buffer, mi_proceso);
    end;
end;

// Apartado 3: Procedimiento que recibe 3 colas de procesos vacías (una por cada nivel
// de prioridad) y el buffer, y clasifica los procesos del buffer en dichas colas según su
// prioridad, respetando el orden de llegada original
//
// SOLUCION: Habría que modificar en la unit el tipo tProceso, así:
//
// prioridad: 0..3;
//
// Y luego el procedimiento generar_procesos, así: 
//
// pproceso^.prioridad:= random(4);
//
// Tras eso, habría que añadir una operación “priority_enqueue” en el TAD ColaProcesos. Finalmente 
// implementaríamos el siguiente procedure:

procedure clasificar_procesos(var buffer,c1,c2,c3: tColaProcesos);
var
  p: tproceso;
begin
  while not is_empty(buffer) do begin
      p:= first(buffer);
      dequeue(buffer);
      case p.prioridad of
        1: enqueue(c1,p);
        2: enqueue(c2,p);
        3: enqueue(c3,p);
      end;
    end;
end;    

// Apartado 4: función “in” que determina si un proceso de cierto nombre se encuentra 
//en espera en el sistema y de estar, dónde (buffer, cola1, cola2 o cola3).
//
// SOLUCIÓN: Primero habría que añadir a la unit la función in_queue que determina si un 
// cierto proceso está en una cola o no
//
// Una vez hecho esto, programar la función “in” que está enfocada a que devuelva un 
// entero que será 0 si aún no ha sido clasificada en su cola (está en buffer), 1, 2 o 3 
// si está en su cola y -1 si no está en el sistema. Algo muy sencillo, así:

function in_system(id_proceso: string; buffer, c1,c2,c3: tColaProcesos): integer;
begin
  if in_queue(buffer, id_proceso) then  in_system:= 0
  else if in_queue(c1, id_proceso) then in_system:= 1
  else if in_queue(c2, id_proceso) then in_system:= 2
  else if in_queue(c3, id_proceso) then in_system:= 3
  else in_system:= -1
end;  


// Apartado 5: Mostrar por pantalla todos los procesos que van a ejecutarse y su orden

procedure mostrar_procesos(var buffer,c1,c2,c3: tColaProcesos);
var
  p: tproceso;
  prioritarios: integer;
begin
  writeln(num_elems(buffer),' procesos en espera');
  if not is_empty(c1) then begin
      prioritarios:=0;
      p:= first(c1);
      if p.prioridad = 0 then prioritarios:= prioritarios + 1;
  end;
  writeln(prioritarios,' de maxima prioridad');
  writeln(num_elems(c1)-prioritarios,' de prioridad 1');
  writeln(num_elems(c2) + num_elems(c3),' de prioridad inferior');
end;
