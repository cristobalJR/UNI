unit uColaProcesos;

interface
  type

    tProceso = record
      id: string;
      prioridad: 1..3;
    end;

    nodo = record
      info: tProceso;
      sig: ^nodo;
    end;

    tcolaProcesos = record
      first, last: ^nodo
    end;

  procedure initialize(var c: tcolaProcesos);
  function first(c: tcolaProcesos): tProceso;
  function last(c: tcolaProcesos): tProceso;
  function is_empty(c: tcolaProcesos): boolean;
  procedure enqueue(var c: tcolaProcesos; p: tProceso);   
  procedure dequeue(var c: tcolaProcesos);
  procedure priority_enqueue(var c: tcolaProcesos; p: tProceso);
  function in_queue(cola: tcolaProcesos; id_proceso:string): boolean;

implementation

  procedure initialize(var c: tcolaProcesos);
  begin
    c.first := nil;
    c.last := nil;
  end;

  function is_empty(c: tcolaProcesos): boolean;
  begin
    is_empty:= (c.first = nil);
  end;

  function first(c: tcolaProcesos): tProceso;
  begin
    first:= c.first^.info;
  end;

  function last(c: tcolaProcesos): tProceso;
  begin
    first:= c.last^.info;
  end;

  procedure enqueue(var c: tcolaProcesos; p: tProceso);
  var
    new_node: ^nodo;
  begin
    new(new_node);
    new_node^.info:= p;
    new_node^.sig:= nil;
    if is_empty(c) then begin
      c.first:=new_node;
      c.last:= new_node;
     end
    else begin
      c.last^.sig:=new_node;
      c.last:= new_node;
     end;
  end;

  procedure dequeue(var c: tcolaProcesos);
  var
    aux: ^nodo;
  begin
    if not is_empty(c) then begin
      aux:= c.first;
      c.first := c.first^.sig;
      if c.first = nil then c.last:= nil;
      dispose(aux);
    end;
  end;    

  procedure priority_enqueue(var c: tcolaProcesos; p: tProceso);
  var
    new_node: ^nodo;
  begin
    new(new_node);
    new_node^.info:= p;
    new_node^.sig:= c.first;
    if c.first = nil then c.last:= new_node;
    c.first:= new_node;
  end;

  function in_queue(cola: tcolaProcesos; id_proceso:string): boolean;
  var
    encontrado: boolean;
    aux:^nodo;
  begin
    encontrado:= false;
    if not is_empty(cola) then begin
        aux:= cola.first;
        while (not encontrado) and (aux<>nil) do begin
          encontrado:= id_proceso = aux^.info.id;
          aux:= aux^.sig;
        end;
      end;
    in_queue:= encontrado;
  end;
